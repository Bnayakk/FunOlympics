/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_bv_activities_store`; */
/* PRE_TABLE_NAME: `1665125629_wp_bv_activities_store`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_bv_activities_store` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `site_id` int(11) NOT NULL, `user_id` int(11) DEFAULT 0, `username` text COLLATE utf8mb4_unicode_ci DEFAULT '', `request_id` text COLLATE utf8mb4_unicode_ci DEFAULT '', `ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '', `event_type` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', `event_data` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL, `time` int(11) DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1665125629_wp_bv_activities_store` (`id`, `site_id`, `user_id`, `username`, `request_id`, `ip`, `event_type`, `event_data`, `time`) VALUES (90,1,1,'bayadmin','73466923563346c8caa5b7','2400:1a00:b111:7c3b:989b:308f:3075:d7b5','activate_plugin','a:1:{s:6:\"plugin\";s:31:\"backup-backup/backup-backup.php\";}',1664380047),(91,1,1,'bayadmin','58714294163347076bf6cf','2400:1a00:b111:7c3b:989b:308f:3075:d7b5','deactivate_plugin','a:1:{s:6:\"plugin\";s:40:\"blogvault-real-time-backup/blogvault.php\";}',1664381048);
