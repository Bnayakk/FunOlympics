/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_term_relationships`; */
/* PRE_TABLE_NAME: `1665125629_wp_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_term_relationships` ( `object_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_order` int(11) NOT NULL DEFAULT 0, PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1665125629_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (423,3,0),(424,2,0),(425,3,0),(426,3,0),(427,4,0),(428,3,0),(429,4,0),(430,2,0),(431,2,0),(432,2,0),(432,4,0),(433,4,0),(434,2,0),(435,4,0),(521,6,0),(1276,7,0),(1300,8,0),(1309,8,0),(1316,9,0),(1676,45,0),(1678,45,0),(1680,45,0),(1681,45,0),(1682,45,0),(1683,45,0),(1685,45,0),(1796,45,0),(1811,45,0),(1812,45,0),(2019,61,0),(2069,62,0),(2097,63,0),(2098,63,0),(2106,45,0),(2107,63,0),(2108,63,0),(2135,64,0),(2137,62,0),(2218,63,0),(2219,63,0),(2220,63,0),(2221,63,0),(2222,63,0),(2334,1,0),(2387,45,0);
