/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpforms_tasks_meta`; */
/* PRE_TABLE_NAME: `1665125629_wp_wpforms_tasks_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_wpforms_tasks_meta` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL, `date` datetime NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1665125629_wp_wpforms_tasks_meta` (`id`, `action`, `data`, `date`) VALUES (1,'wpforms_process_forms_locator_scan','W10=','2022-09-03 11:49:56'),(2,'wpforms_admin_addons_cache_update','W10=','2022-09-03 11:49:57'),(3,'wpforms_admin_builder_templates_cache_update','W10=','2022-09-03 11:49:57'),(26,'wpforms_builder_help_cache_update','W10=','2022-09-26 07:57:26'),(37,'wpforms_process_forms_locator_scan','W10=','2022-10-03 18:31:17'),(38,'wpforms_process_forms_locator_scan','W10=','2022-10-03 18:31:17'),(39,'wpforms_admin_addons_cache_update','W10=','2022-10-03 18:31:17'),(40,'wpforms_admin_builder_templates_cache_update','W10=','2022-10-03 18:31:17');
