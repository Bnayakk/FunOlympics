/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_hurrytimer_evergreen`; */
/* PRE_TABLE_NAME: `1665125629_wp_hurrytimer_evergreen`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_hurrytimer_evergreen` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `countdown_id` bigint(20) unsigned NOT NULL, `client_ip_address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, `expired` tinyint(1) unsigned DEFAULT NULL, `client_expires_at` bigint(20) unsigned NOT NULL, `reset_token` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `destroy_at` timestamp NULL DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
