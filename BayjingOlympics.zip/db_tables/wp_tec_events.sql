/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_tec_events`; */
/* PRE_TABLE_NAME: `1665125629_wp_tec_events`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_tec_events` ( `event_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `post_id` bigint(20) unsigned NOT NULL, `start_date` datetime NOT NULL, `end_date` datetime DEFAULT NULL, `timezone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UTC', `start_date_utc` datetime NOT NULL, `end_date_utc` datetime DEFAULT NULL, `duration` mediumint(30) DEFAULT 7200, `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), `hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL, PRIMARY KEY (`event_id`), UNIQUE KEY `post_id` (`post_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
