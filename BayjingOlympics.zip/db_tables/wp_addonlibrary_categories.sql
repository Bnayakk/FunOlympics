/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_addonlibrary_categories`; */
/* PRE_TABLE_NAME: `1665125629_wp_addonlibrary_categories`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_addonlibrary_categories` ( `id` int(9) NOT NULL AUTO_INCREMENT, `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `ordering` int(11) NOT NULL, `params` text COLLATE utf8mb4_unicode_ci NOT NULL, `type` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL, `parent_id` int(9) DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1665125629_wp_addonlibrary_categories` (`id`, `title`, `alias`, `ordering`, `params`, `type`, `parent_id`) VALUES (1,'Creative Widgets','creative_widgets',1,'','elementor',0),(2,'Marketing Widgets','marketing_widgets',2,'','elementor',0),(3,'free','free',3,'','elementor',0),(4,'Media Widgets','media_widgets',4,'','elementor',0),(5,'Button Widgets','button_widgets',5,'','elementor',0);
