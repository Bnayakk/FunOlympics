/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_tec_occurrences`; */
/* PRE_TABLE_NAME: `1665125629_wp_tec_occurrences`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_tec_occurrences` ( `occurrence_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `event_id` bigint(20) unsigned NOT NULL, `post_id` bigint(20) unsigned NOT NULL, `start_date` datetime NOT NULL, `start_date_utc` datetime NOT NULL, `end_date` datetime NOT NULL, `end_date_utc` datetime NOT NULL, `duration` mediumint(30) DEFAULT 7200, `hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL, `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), PRIMARY KEY (`occurrence_id`), UNIQUE KEY `hash` (`hash`), KEY `event_id` (`event_id`), CONSTRAINT `wp_tec_occurrences_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `wp_tec_events` (`event_id`) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
