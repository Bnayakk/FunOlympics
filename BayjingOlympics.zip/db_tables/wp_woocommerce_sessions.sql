/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_woocommerce_sessions`; */
/* PRE_TABLE_NAME: `1665125629_wp_woocommerce_sessions`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_woocommerce_sessions` ( `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL, `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL, `session_expiry` bigint(20) unsigned NOT NULL, PRIMARY KEY (`session_id`), UNIQUE KEY `session_key` (`session_key`)) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
