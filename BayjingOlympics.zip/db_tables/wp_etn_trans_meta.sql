/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_etn_trans_meta`; */
/* PRE_TABLE_NAME: `1665125629_wp_etn_trans_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_etn_trans_meta` ( `meta_id` mediumint(9) NOT NULL AUTO_INCREMENT, `event_id` mediumint(9) NOT NULL, `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL, PRIMARY KEY (`meta_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
