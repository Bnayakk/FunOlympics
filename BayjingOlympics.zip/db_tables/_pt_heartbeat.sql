/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `_pt_heartbeat`; */
/* PRE_TABLE_NAME: `1665125629__pt_heartbeat`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629__pt_heartbeat` ( `ts` varchar(26) NOT NULL, `server_id` int(10) unsigned NOT NULL, `file` varchar(255) DEFAULT NULL, `position` bigint(20) unsigned DEFAULT NULL, `relay_master_log_file` varchar(255) DEFAULT NULL, `exec_master_log_pos` bigint(20) unsigned DEFAULT NULL, PRIMARY KEY (`server_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `1665125629__pt_heartbeat` (`ts`, `server_id`, `file`, `position`, `relay_master_log_file`, `exec_master_log_pos`) VALUES ('2022-10-07T06:53:49.004730',314111479,'mysql-bin.000076',3068699,'','');
