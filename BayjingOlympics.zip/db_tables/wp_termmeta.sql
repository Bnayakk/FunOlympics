/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_termmeta`; */
/* PRE_TABLE_NAME: `1665125629_wp_termmeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1665125629_wp_termmeta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `term_id` bigint(20) unsigned NOT NULL DEFAULT 0, `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL, PRIMARY KEY (`meta_id`), KEY `term_id` (`term_id`), KEY `meta_key` (`meta_key`(191))) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1665125629_wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES (1,2,'blocksy_demos_imported_term',1),(2,2,'blocksy_demos_imported_term',1),(3,3,'blocksy_demos_imported_term',1),(4,3,'blocksy_demos_imported_term',1),(5,4,'blocksy_demos_imported_term',1),(6,4,'blocksy_demos_imported_term',1),(8,6,'blocksy_demos_imported_term',1),(9,63,'image_id',2009),(10,63,'exclude_search_form',0);
